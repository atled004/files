import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
path="C:/Users/UEM/OneDrive - University Of Engineering & Management/subject/AI/lab/2025/dataset/linear_regression/"
data=pd.read_csv(path+"Boston.csv")
z=pd.DataFrame(data.corr().round(2))
x=data['RM']
y=data['MEDV']
x=pd.DataFrame(x)
y=pd.DataFrame(y)
x_train, x_test, y_train, y_test = train_test_split(x,y,test_size=0.2)
print(x_train.shape)
linearRegressionClassifier = LinearRegression()
linearRegressionClassifier.fit(x_train, y_train)
y_pred=linearRegressionClassifier.predict(x_test)
mean_sq_er=np.sqrt(mean_squared_error(y_test, y_pred))
r_2_er=linearRegressionClassifier.score(x_test,y_test)
print(mean_sq_er)
print(r_2_er)