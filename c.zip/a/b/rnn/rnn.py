import numpy as np
import tensorflow as tf
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, Dense
from tensorflow.keras.utils import to_categorical
from sklearn import preprocessing
from sklearn.preprocessing import LabelEncoder
path="C:/Users/UEM/OneDrive - University Of Engineering & Management/subject/AI/lab/2024/dataset/rnn/"
data=pd.read_csv(path+"Iris_Dataset.csv")
X=data.drop("species",axis=1)
data1=pd.read_csv(path+"Iris_Dataset.csv")
data1.drop(data1.iloc[:,0:4],axis=1, inplace=True)
Y=data1
le = LabelEncoder()
labels = le.fit_transform(Y)
print(Y)
print(labels)


#X_train,X_test,Y_train,Y_test=train_test_split(X,Y,test_size=0.4,random_state=15)
X_train,X_test,Y_train,Y_test=train_test_split(X,labels,test_size=0.2,random_state=15)




print(X_train.shape)
print(Y_train.shape)
print(X_test.shape)
print(Y_test.shape)

Y_train=to_categorical(Y_train, num_classes=3)
Y_test=to_categorical(Y_test, num_classes=3)
X_train=np.array(X_train)
Y_train=np.array(Y_train)
X_test=np.array(X_test)
Y_test=np.array(Y_test)


X_train=X_train.reshape(-1,120,4)
Y_train=Y_train.reshape(-1,120,3)
X_test=X_test.reshape(-1,30,4)
Y_test=Y_test.reshape(-1,30,3)


model = Sequential()
model.add(SimpleRNN(units=64, input_shape=(120,4),return_sequences=True))  # Adjust units and input_shape as needed
model.add(Dense(3, activation='sigmoid'))  # For binary classification, adjust activation for other tasks
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])  # Adjust loss and metrics for your task
model.fit(X_train, Y_train, epochs=120, batch_size=32, validation_data=(X_test, Y_test))

loss, accuracy = model.evaluate(X_test, Y_test)
print('Test Loss:', loss)
print('Test Accuracy:', accuracy)



#log_reg=LogisticRegression(max_iter=10000)
'''knn_classifier=KNeighborsClassifier(n_neighbors=5)




knn_classifier.fit(X_train, Y_train)
print(knn_classifier.get_params())
Y_pred=knn_classifier.predict(X_test)
result=0
confusion_matrix = confusion_matrix(Y_test, Y_pred)
#f1_value=f1_score(Y_test,Y_pred)
acc=accuracy_score(Y_test,Y_pred)
#print("F1 score is: ",f1_value*100)
print("Accuracy using function is: ",acc*100)
print(confusion_matrix)'''





